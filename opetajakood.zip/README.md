# Tundide tagaside
## 12. tund
Täna õppisime/täna sain selgeks/täna ei saanud selgeks/olen kaotanud järje/ ei tea mida eluga pihta hakata/kõik pekkis/MA saan ikka täpselt aru/ 

## 13.tund
jiahUDGHAJSHGDJASHDJA
**ADASDASDASD**